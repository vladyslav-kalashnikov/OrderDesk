"""«Акаунти»: email + пароль (у Keychain) + проксі; вхід і збереження сесії."""
from PySide6.QtWidgets import (
    QComboBox, QDialog, QDialogButtonBox, QFormLayout, QLabel, QLineEdit, QVBoxLayout,
)

from ..core.db import Database
from ..core.engine import Engine
from ..core.entities import Account, AccountStatus
from ..core.fingerprint import delete_fingerprint
from ..core.secrets import delete_secret, get_secret, set_secret
from .common import DataTable, Page, TableOrEmpty, button, confirm, info, state_cell

COL_ID, COL_EMAIL, COL_BROWSER, COL_PROXY, COL_DELIVERY, COL_PAYMENT, COL_SESSION, COL_STATUS, COL_ERROR = range(9)


class PasswordDialog(QDialog):
    """Новий пароль двічі — щоб помилка в одному символі не зламала вхід."""

    def __init__(self, email: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Змінити пароль")
        self.setMinimumWidth(420)
        layout = QVBoxLayout(self)
        form = QFormLayout()
        form.setSpacing(10)

        account = QLineEdit(email)
        account.setReadOnly(True)
        self.password = QLineEdit()
        self.password.setEchoMode(QLineEdit.EchoMode.Password)
        self.repeat = QLineEdit()
        self.repeat.setEchoMode(QLineEdit.EchoMode.Password)
        form.addRow("Акаунт", account)
        form.addRow("Новий пароль", self.password)
        form.addRow("Ще раз", self.repeat)
        layout.addLayout(form)
        hint = QLabel("Тут змінюється лише пароль, збережений у програмі (Keychain). "
                      "На самому сайті пароль міняйте в його налаштуваннях.")
        hint.setObjectName("hint")
        hint.setWordWrap(True)
        layout.addWidget(hint)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self._accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _accept(self) -> None:
        if not self.password.text():
            info(self, "Пароль", "Введіть новий пароль.")
            return
        if self.password.text() != self.repeat.text():
            info(self, "Пароль", "Паролі не збігаються.")
            return
        self.accept()


class AccountDialog(QDialog):
    def __init__(self, db: Database, account: Account | None = None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Акаунт" if account else "Новий акаунт")
        self.setMinimumWidth(440)
        self._account = account
        layout = QVBoxLayout(self)
        form = QFormLayout()
        form.setSpacing(10)

        self.email = QLineEdit(account.email if account else "")
        self.email.setPlaceholderText("user@example.com")
        self.email.setReadOnly(account is not None)
        self.password = QLineEdit()
        self.password.setEchoMode(QLineEdit.EchoMode.Password)
        has_password = bool(account and get_secret("account", account.email))
        self.password.setPlaceholderText("збережено в Keychain — залиште порожнім" if has_password else "пароль від сайту")

        self.adspower = QLineEdit(account.adspower_id or "" if account else "")
        self.adspower.setPlaceholderText("ID або Serial Number (напр. 1 або k9abc12)")

        self.proxy = QComboBox()
        self.proxy.addItem("Без проксі", None)
        for proxy in db.proxies():
            self.proxy.addItem(f"{proxy.display}  ·  {proxy.status}", proxy.id)
        if account and account.proxy_id:
            self.proxy.setCurrentIndex(max(0, self.proxy.findData(account.proxy_id)))

        self.carrier = QComboBox()
        self.carrier.addItem("Нова Пошта", "nova")
        self.carrier.addItem("Укрпошта", "ukr")
        if account:
            self.carrier.setCurrentIndex(1 if getattr(account, "delivery_carrier", "nova") == "ukr" else 0)

        self.city = QLineEdit(account.delivery_city or "" if account else "")
        self.city.setPlaceholderText("напр. Київ (порожньо — з налаштувань)")

        self.warehouse = QLineEdit(account.delivery_warehouse or "" if account else "")
        self.warehouse.setPlaceholderText("напр. Відділення №1 або індекс")

        self.payment = QComboBox()
        self.payment.addItem("Оплата карткою онлайн", "card_link")
        self.payment.addItem("Післяплата (накладений платіж)", "cod")
        if account and getattr(account, "payment_method", "card_link") == "cod":
            self.payment.setCurrentIndex(1)

        form.addRow("Email", self.email)
        form.addRow("Пароль", self.password)
        form.addRow("AdsPower профіль", self.adspower)
        form.addRow("Проксі", self.proxy)
        form.addRow("Служба доставки", self.carrier)
        form.addRow("Місто", self.city)
        form.addRow("Відділення / індекс", self.warehouse)
        form.addRow("Спосіб оплати", self.payment)
        layout.addLayout(form)
        hint = QLabel("Пароль зберігається в Keychain. Кожен акаунт автоматично отримує власний ізольований "
                      "антидетект-профіль (захист WebRTC, унікальний Canvas, WebGL, Audio, екран та CPU/RAM) — "
                      "поле AdsPower можна залишити порожнім.")
        hint.setObjectName("hint")
        layout.addWidget(hint)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self._accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _accept(self) -> None:
        if "@" not in self.email.text():
            info(self, "Email", "Вкажіть коректний email.")
            return
        if not self._account and not self.password.text():
            info(self, "Пароль", "Для нового акаунта потрібен пароль.")
            return
        self.accept()


class AccountsPage(Page):
    def __init__(self, db: Database, engine: Engine, parent=None):
        super().__init__("Акаунти", "Сесії зберігаються після входу і використовуються всіма завданнями акаунта", parent)
        self.db, self.engine = db, engine

        add = button("+ Акаунт", "primary")
        login = button("Увійти", tooltip="Увійти автоматично (логін/пароль) і зберегти сесію")
        manual = button("Увійти вручну", tooltip="Відкриє вікно браузера: капчу чи 2FA вводите самі, сесія збережеться")
        assign_proxies = button("Роздати проксі", tooltip="Автоматично прив'язати вільні проксі до акаунтів без проксі (1 проксі = 1 акаунт)")
        password = button("Змінити пароль", tooltip="Оновити збережений у Keychain пароль виділеного акаунта")
        reset = button("Скинути сесію")
        delete = button("Видалити", "danger")
        for b in (add, login, manual, assign_proxies, password, reset, delete):
            self.actions.addWidget(b)
        add.clicked.connect(self.add_account)
        assign_proxies.clicked.connect(self.auto_assign_proxies)
        password.clicked.connect(self.change_password)
        login.clicked.connect(lambda: self.login_selected(False))
        manual.clicked.connect(lambda: self.login_selected(True))
        reset.clicked.connect(self.reset_sessions)
        delete.clicked.connect(self.delete_selected)

        self.table = DataTable(
            ["ID", "EMAIL", "БРАУЗЕР", "ПРОКСІ", "ДОСТАВКА", "ОПЛАТА", "СЕСІЯ", "СТАТУС", "ОСТАННЯ ПОМИЛКА"],
            stretch=(COL_ERROR,),
            widths={
                COL_ID: 44,
                COL_EMAIL: 165,
                COL_BROWSER: 110,
                COL_PROXY: 120,
                COL_DELIVERY: 150,
                COL_PAYMENT: 105,
                COL_SESSION: 110,
                COL_STATUS: 85,
            },
        )
        self.table.doubleClicked.connect(lambda index: self.edit_account(self.table.row_id(index.row())))
        self.stack = TableOrEmpty(self.table, "Акаунтів ще немає",
                                  "Крок 1: «+ Акаунт» (email і пароль). Крок 2: «Увійти вручну» — пройдіть вхід у вікні браузера.")
        tip = QLabel("Порада: подвійний клік по акаунту відкриває його налаштування. «Увійти вручну» — найнадійніший "
                     "спосіб, якщо сайт просить перевірку безпеки.")
        tip.setObjectName("hint")
        tip.setWordWrap(True)
        self.body.addWidget(tip)
        self.body.addWidget(self.stack)
        self.refresh()

    def refresh(self) -> None:
        proxies = {p.id: p.display for p in self.db.proxies()}
        rows = []
        for a in self.db.accounts():
            has_session = self.engine.state_path(a.id).exists()
            session = ("✓ збережена" + (f" · {a.session_saved_at}" if a.session_saved_at else "")) if has_session else "— потрібен вхід"
            carrier_label = "НП" if getattr(a, "delivery_carrier", "nova") == "nova" else "УП"
            city_str = a.delivery_city or ""
            wh_str = a.delivery_warehouse or ""
            if city_str and wh_str:
                delivery_disp = f"{carrier_label}: {city_str}, {wh_str}"
            elif city_str:
                delivery_disp = f"{carrier_label}: {city_str}"
            elif wh_str:
                delivery_disp = f"{carrier_label}: {wh_str}"
            else:
                delivery_disp = f"{carrier_label}: дефолт"
            payment_disp = "Картка" if getattr(a, "payment_method", "card_link") == "card_link" else "Післяплата"
            browser_disp = f"⚡ Ads #{a.adspower_id}" if a.adspower_id else "🛡 Антидетект"
            rows.append((a.id, [
                str(a.id), a.email, browser_disp, proxies.get(a.proxy_id, "—"), delivery_disp, payment_disp, session, state_cell(a.status), a.last_error or "",
            ]))
        self.table.set_rows(rows)
        self.stack.update_state()
        active = sum(1 for a in self.db.accounts() if a.status == "Активний")
        self.subtitle.setText(f"Акаунтів: {len(rows)} · активних: {active}")

    def add_account(self) -> None:
        dialog = AccountDialog(self.db, parent=self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        email = dialog.email.text().strip()
        if any(a.email == email for a in self.db.accounts()):
            info(self, "Вже є", f"Акаунт {email} уже додано.")
            return
        set_secret("account", email, dialog.password.text())
        self.db.add_account(
            email,
            dialog.proxy.currentData(),
            delivery_carrier=dialog.carrier.currentData(),
            delivery_city=dialog.city.text().strip() or None,
            delivery_warehouse=dialog.warehouse.text().strip() or None,
            payment_method=dialog.payment.currentData(),
            adspower_id=dialog.adspower.text().strip() or None,
        )
        self.refresh()

    def edit_account(self, account_id: int) -> None:
        account = self.db.account(account_id)
        if not account:
            return
        dialog = AccountDialog(self.db, account, self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        if dialog.password.text():
            set_secret("account", account.email, dialog.password.text())
        new_ads_id = dialog.adspower.text().strip() or None
        if dialog.proxy.currentData() != account.proxy_id or new_ads_id != account.adspower_id:
            # Зміна проксі або профілю AdsPower — скидаємо збережену сесію
            self._drop_session(account.id)
        self.db.update_account_settings(
            account.id,
            dialog.proxy.currentData(),
            delivery_carrier=dialog.carrier.currentData(),
            delivery_city=dialog.city.text().strip() or None,
            delivery_warehouse=dialog.warehouse.text().strip() or None,
            payment_method=dialog.payment.currentData(),
            adspower_id=new_ads_id,
        )
        self.refresh()

    def change_password(self) -> None:
        ids = self.table.selected_ids()
        if len(ids) != 1:
            info(self, "Оберіть акаунт", "Виділіть один акаунт у таблиці.")
            return
        account = self.db.account(ids[0])
        dialog = PasswordDialog(account.email, self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        set_secret("account", account.email, dialog.password.text())
        if account.status == AccountStatus.ERROR.value:
            # Помилка могла бути через старий пароль — даємо наступному входу спробувати новий
            self.db.set_account_status(account.id, AccountStatus.NEW)
        self.engine.log("INFO", f"account#{account.id}", f"{account.email}: пароль оновлено")
        self.refresh()
        info(self, "Пароль", f"Пароль для {account.email} оновлено.")

    def login_selected(self, interactive: bool) -> None:
        ids = self.table.selected_ids()
        if not ids:
            info(self, "Оберіть акаунт", "Виділіть акаунт(и) в таблиці.")
            return
        if interactive and len(ids) > 1:
            info(self, "По одному", "Ручний вхід — по одному акаунту за раз.")
            return
        for account_id in ids:
            self.table.set_cell(account_id, COL_STATUS, "Вхід…")
            self.engine.login_account(account_id, interactive)

    def auto_assign_proxies(self) -> None:
        all_proxies = self.db.proxies()
        if not all_proxies:
            info(self, "Немає проксі", "Спочатку додайте проксі у вкладці «Проксі».")
            return
        accounts = self.db.accounts()
        selected_ids = set(self.table.selected_ids())
        targets = [a for a in accounts if (a.id in selected_ids if selected_ids else not a.proxy_id)]
        if not targets:
            info(self, "Усі мають проксі", "Усі акаунти вже мають прив'язані проксі (або виділіть акаунти, яким треба замінити проксі).")
            return

        used_proxy_ids = {a.proxy_id for a in accounts if a.proxy_id and a.id not in {t.id for t in targets}}
        # Спочатку робочі вільні проксі, потім інші вільні, потім по колу
        working_free = [p for p in all_proxies if p.id not in used_proxy_ids and p.status == "Працює"]
        other_free = [p for p in all_proxies if p.id not in used_proxy_ids and p.status != "Працює"]
        pool = working_free + other_free
        if not pool:
            pool = list(all_proxies)

        assigned = 0
        for idx, acc in enumerate(targets):
            proxy = pool[idx % len(pool)]
            if acc.proxy_id != proxy.id:
                self._drop_session(acc.id)
                self.db.update_account_settings(
                    acc.id,
                    proxy.id,
                    delivery_carrier=acc.delivery_carrier,
                    delivery_city=acc.delivery_city,
                    delivery_warehouse=acc.delivery_warehouse,
                    payment_method=acc.payment_method,
                    adspower_id=acc.adspower_id,
                )
                assigned += 1
        self.refresh()
        info(self, "Проксі розподілено", f"Прив'язано проксі для акаунтів: {assigned}.")

    def _drop_session(self, account_id: int) -> None:
        self.engine.state_path(account_id).unlink(missing_ok=True)
        delete_fingerprint(account_id)
        self.db.clear_account_session(account_id)

    def reset_sessions(self) -> None:
        ids = self.table.selected_ids()
        if not ids or not confirm(self, "Скинути сесію", f"Видалити збережені сесії ({len(ids)})? "
                                                         "Наступний запуск увійде заново."):
            return
        for account_id in ids:
            self._drop_session(account_id)
        self.refresh()

    def delete_selected(self) -> None:
        ids = self.table.selected_ids()
        if not ids:
            return
        if set(ids) & {t.account_id for t in self.db.tasks() if t.id in self.engine.running_task_ids()}:
            info(self, "Є запущені завдання", "Спочатку зупиніть завдання цих акаунтів.")
            return
        if not confirm(self, "Видалити акаунти",
                       f"Видалити акаунтів: {len(ids)}? Разом з ними видаляться їхні завдання, "
                       "сесії та паролі в Keychain."):
            return
        for account_id in ids:
            account = self.db.account(account_id)
            delete_secret("account", account.email)
            self._drop_session(account_id)
            self.db.delete_account(account_id)
        self.refresh()
